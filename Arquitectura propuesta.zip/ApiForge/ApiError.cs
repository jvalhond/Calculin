﻿/*
 * This library is provided without warranty under the MIT license
 * Created by Jacob Davis <jacob@1forge.com>
 */

namespace ForexQuotes
{
    public class ApiError
    {
        public string message;
        public bool error;
    }
}