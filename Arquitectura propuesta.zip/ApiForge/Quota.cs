﻿/*
 * This library is provided without warranty under the MIT license
 * Created by Jacob Davis <jacob@1forge.com>
 */

using Newtonsoft.Json;

namespace ForexQuotes
{
    public class Quota : QuotaBase
    {
   
    }
}