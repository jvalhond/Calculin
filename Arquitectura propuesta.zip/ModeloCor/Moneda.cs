﻿
namespace ModeloCore
{
    public class Moneda
    { 
        public int Id { get; set; }
        public string IdentificadorMoneda { get; set; } // EUR
        public string Nombre { get; set; } // EUROS
    }
}