﻿using System.Collections.Generic;

namespace ModeloCore
{
    public class Pais
    {
        public int Id { get; set; }
        public string IdPais { get; set; }
        public string Nombre { get; set; }
    }
}
